<?php
header("Access-Control-Allow-Origin: *");
echo date("Ymd");
?>
